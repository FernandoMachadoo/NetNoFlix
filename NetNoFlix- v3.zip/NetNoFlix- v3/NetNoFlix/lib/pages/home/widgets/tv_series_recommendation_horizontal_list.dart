import 'package:flutter/material.dart';
import 'package:movie_app/models/tv_series_recommendations_model.dart';
import 'tv_series_recommendation_item.dart'; // Certifique-se de importar o TvSeriesRecommendationItem

class TvSeriesRecommendationHorizontalList extends StatelessWidget {
  final List<TvSeriesResult> recommendations;

  const TvSeriesRecommendationHorizontalList({
    Key? key,
    required this.recommendations,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 220, // Altura adequada para as recomendações
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: recommendations.length,
        itemBuilder: (context, index) {
          final recommendation = recommendations[index];
          return TvSeriesRecommendationItem(recommendation: recommendation);
        },
      ),
    );
  }
}
